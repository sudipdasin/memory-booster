# Permanent CI provider policy — CircleCI

**Recorded 2026-11-22.** Per project owner: GitHub Actions usage is exhausted and a billing restriction prevents jobs executing. Use **CircleCI** as the exclusive active CI provider for tests, security checks, packaging and authorized releases. GitHub remains source control and PR/release storage. Do not upgrade billing, re-enable GitHub Actions or switch providers without owner authorization.

Canonical policy: https://github.com/sudipdasin/CI-Master-Control/blob/main/docs/STANDING_CI_PROVIDER_POLICY.md

**MemBoost v0.1.1:** The repository contains C++ application code and CircleCI automated unit, CLI, virtual-X11 and packaging checks. CircleCI enrollment and successful native build/test/package statuses were observed for v0.1.1 and both v0.3.0 CI jobs. The final v1.0.0 commit requires its own CI statuses before promotion.

**0.3.0 development milestone:** CircleCI checks the GUI and headless sanitizer jobs; a passed local build is not a substitute for observing remote statuses on the exact commit.
